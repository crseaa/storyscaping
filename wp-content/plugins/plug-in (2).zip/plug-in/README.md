# wordPress-partyvibesplugin

![Chocolate Chip Cookies](screenshot.png)

***

## Download the repository from GitHub.com 
Download the repository **wordpress-partyvibesplugin-main** to your PC/MAC.

## Unzip the repository
After downloading your repository **wordpress-partyvibesplugin-main** to your PC/MAC, you will have to unzip the zip file and you will end up with a folder named **wordpress-partyvibesplugin-main**

## Rename folder
Next, go and rename your the folder from the previous step to **partyvibesplugin**

## Copy folder into the WordPress wp-content/plugins folder
Copy the **partyvibesplugin** folder and insert it into your wordpress root-directory --> wp-content --> **plugins**

## Go to WordPress Dashboard and Activate
Next, you need to login into your WordPress Dashboard and click on plugin in the menu-bar. Here you will have to activate your newly added plugin - **Partyvibes Plugin**.

## Add a new WordPress Page
Next, go to your WordPress Dashboard and click on **Pages**.  Now add a new page. Give it a title and insert the following shortcode - **[show_partyvibesplugin]**

## Visit your newly created page
Finally, go and open your newly created WordPress page - where your WordPress Partyvibes plugin will appear.
