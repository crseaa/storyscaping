jQuery(document).ready(function( $ ) {
  $('.close-button').on('click', function() {
    $('.container').hide();
  })
});

jQuery(document).ready(function( $ ) {
  $('#laes-mere-button').on('click', function() {
    $('.container').hide();
  })
});